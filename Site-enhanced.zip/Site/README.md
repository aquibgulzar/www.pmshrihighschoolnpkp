# PM SHRI Govt. High School Nowpora Website

## Run locally
Requires Node.js 18+; no third-party packages are needed.

```bash
npm start
```

Open http://127.0.0.1:3000

## Backend endpoints
- `GET /api/health` — checks that the server is running.
- `POST /api/admissions` — validates and saves pre-registration records to `data/admissions.json`.

The data directory is created automatically. Registration records contain personal information, so keep the server private, use HTTPS when deployed, restrict filesystem access, and follow the school's data-retention and consent requirements. This starter backend is intended for local/testing use; production deployment should add authentication for any administrative access, rate limiting, backups, and a managed database.
