// Lightweight Node.js backend for PM SHRI Govt. High School Nowpora website.
// No third-party packages required. Run with: npm start
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const DATA_FILE = path.join(DATA_DIR, 'admissions.json');
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '127.0.0.1';
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]\n', { mode: 0o600 });

const mime = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.jpeg': 'image/jpeg',
  '.jpg': 'image/jpeg', '.png': 'image/png', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.json': 'application/json; charset=utf-8'
};
function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, {
    'Content-Type': type,
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'SAMEORIGIN',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Cache-Control': 'no-store'
  });
  res.end(type.startsWith('application/json') ? JSON.stringify(body) : body);
}
function readJson(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (data.length > 16 * 1024) {
        reject(new Error('Request body is too large.'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(data || '{}')); }
      catch { reject(new Error('Please submit valid JSON.')); }
    });
    req.on('error', reject);
  });
}
function clean(value, max) {
  return typeof value === 'string' ? value.trim().replace(/\s+/g, ' ').slice(0, max) : '';
}
function validPhone(phone) { return /^[0-9]{10}$/.test(phone); }

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/api/health' && req.method === 'GET') {
    return send(res, 200, { status: 'ok', service: 'PM SHRI Nowpora website API' });
  }
  if (url.pathname === '/api/admissions' && req.method === 'POST') {
    try {
      const input = await readJson(req);
      const student = clean(input.student, 100);
      const parent = clean(input.parent, 100);
      const className = clean(input.className, 30);
      const phone = clean(input.phone, 10);
      if (student.length < 2 || parent.length < 2) {
        return send(res, 400, { error: 'Enter the student and parent/guardian full names.' });
      }
      if (!/^[\p{L}\p{M} .'-]+$/u.test(student) || !/^[\p{L}\p{M} .'-]+$/u.test(parent)) {
        return send(res, 400, { error: 'Names may contain letters, spaces, apostrophes, dots, and hyphens only.' });
      }
      if (!className || className.length > 30) {
        return send(res, 400, { error: 'Please select a valid class.' });
      }
      if (!validPhone(phone)) {
        return send(res, 400, { error: 'Enter a valid 10-digit mobile number.' });
      }
      const entries = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
      const registrationId = 'PMSHRI-NPKP-' + crypto.randomBytes(4).toString('hex').toUpperCase();
      const record = {
        registrationId, student, parent, className, phone,
        submittedAt: new Date().toISOString(), status: 'pending'
      };
      entries.push(record);
      fs.writeFileSync(DATA_FILE, JSON.stringify(entries, null, 2) + '\n', { mode: 0o600 });
      return send(res, 201, {
        message: 'Pre-registration saved successfully. Please contact the school to complete admission.',
        registrationId,
        status: record.status
      });
    } catch (err) {
      if (!res.headersSent && !res.destroyed) {
        return send(res, 400, { error: err.message || 'Could not process the registration.' });
      }
    }
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    return send(res, 405, { error: 'Method not allowed.' });
  }
  let pathname = decodeURIComponent(url.pathname);
  if (pathname === '/') pathname = '/index.html';
  const requested = path.resolve(ROOT, '.' + pathname);
  if (!requested.startsWith(ROOT + path.sep) || requested === DATA_FILE || requested.startsWith(DATA_DIR + path.sep)) {
    return send(res, 403, { error: 'Forbidden.' });
  }
  fs.readFile(requested, (err, contents) => {
    if (err) return send(res, 404, { error: 'Page or file not found.' });
    const type = mime[path.extname(requested).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': type, 'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'strict-origin-when-cross-origin'
    });
    if (req.method === 'HEAD') return res.end();
    res.end(contents);
  });
});
server.listen(PORT, HOST, () => {
  console.log(`Website running at http://${HOST}:${PORT}`);
  console.log(`Health check: http://${HOST}:${PORT}/api/health`);
});
